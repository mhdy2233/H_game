def main():
    print("请输入多行文本（以空行结束）：")
    lines = []
    while True:
        line = input()
        if line.strip() == "":
            break
        lines.append(line)

    # 合并文本并用标记切割
    full_text = ''.join(lines)
    # 替换 [pc] 为结束标志，避免继续叠加
    full_text = full_text.replace("[pc]", "")
    segments = full_text.split("[br]")

    # 构造多段累积文本输出，保留 \n 转义符
    print('\n输出：\n')
    print('    """' + '\n\n'.join(
        '\\n'.join(segments[:i + 1]) for i in range(len(segments))
    ) + '"""')

if __name__ == "__main__":
    main()
